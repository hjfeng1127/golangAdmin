if (!GetToken()){
    window.location.replace("login.html");
}
