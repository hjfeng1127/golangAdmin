package logger

func Error(err error) {

}
