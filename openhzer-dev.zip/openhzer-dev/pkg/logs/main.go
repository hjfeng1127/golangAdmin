package logs

func Init() {

}
