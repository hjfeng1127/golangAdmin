package logs

type Record struct {
}
